# Where is this from? — jeu d'intégration (20 villes, 1 carte, 20 minutes, un podium)

Les joueurs reçoivent le nom d'une ville et posent un pin sur une vraie carte. Plus le pin est proche, plus ils marquent de points (5 000 max par ville). Après chaque ville, tout le monde voit où les autres ont placé leur pin. À la fin du chrono, un podium s'affiche sur tous les écrans.

## Déroulé
1. Les joueurs ouvrent le lien, choisissent un pseudo et attendent dans le salon d'attente.
2. Tu ouvres `/admin` (même adresse + `/admin`), tu entres le mot de passe, tu cliques **Start the game** (20 min par défaut).
3. Chacun avance à son rythme. À la fin de chaque ville : distance, points, anecdote, et les pins des autres joueurs qui ont déjà répondu (ils apparaissent en direct au fur et à mesure).
4. À 00:00, le podium (top 3 + classement) s'affiche pour tout le monde. **Reset** dans `/admin` prépare une nouvelle partie.

Les points sont calculés par le serveur, et la position d'une ville n'est envoyée qu'après la réponse du joueur.

## Mise en ligne, méthode 1 : une seule commande (sans compte, 2 minutes)
Ton ordinateur fait tourner le jeu et un tunnel Cloudflare gratuit lui donne une adresse publique en https.
1. Installe Node.js (version « LTS ») depuis https://nodejs.org et dézippe ce dossier.
2. Ouvre un terminal dans le dossier et lance :
   - Mac / Linux : `ADMIN_PASSWORD=monmotdepasse node online.js`
   - Windows PowerShell : `$env:ADMIN_PASSWORD="monmotdepasse"; node online.js`
3. Après 10 à 20 secondes, le terminal affiche un cadre avec le lien à partager (`https://xxxx.trycloudflare.com`) et le lien du panneau animateur. Si le cadre n'apparaît pas, le tunnel n'a pas pu s'ouvrir : vérifie ta connexion internet ou passe à la méthode 2.

À savoir : le lien change à chaque lancement, et la fenêtre du terminal doit rester ouverte et l'ordinateur allumé pendant toute la partie. Prévu pour quelques dizaines à une centaine de joueurs. Lance-le et teste-le avec ton téléphone avant l'événement.

## Mise en ligne, méthode 2 : lien permanent avec Render (gratuit)
1. Sur https://github.com, crée un compte puis **New repository** (public ou privé). Sur la page du dépôt vide, clique **uploading an existing file**, glisse tout le contenu du dossier dézippé (pas le zip), puis **Commit changes**.
2. Sur https://render.com, crée un compte avec GitHub, puis **New > Blueprint**, choisis ton dépôt et valide. Le fichier `render.yaml` configure tout.
3. Quand le déploiement est terminé, Render affiche l'adresse du jeu (`https://where-is-this-from-xxxx.onrender.com`). Le mot de passe animateur est dans le service, onglet **Environment**, variable `ADMIN_PASSWORD` (tu peux le changer).

L'offre gratuite de Render s'endort après environ 15 minutes sans visite et met près d'une minute à se réveiller : ouvre le lien 5 à 10 minutes avant le début.

## Changer les villes
Les 20 villes sont dans `rounds.json` : nom, pays, latitude, longitude, anecdote affichée après la réponse. Tu peux en modifier ou en remplacer (garde 20 entrées avec des `id` r01 à r20, ou ajuste le nombre : le jeu s'adapte à la taille de la liste).

## Réglages (variables d'environnement)
- `ADMIN_PASSWORD` : mot de passe de `/admin` (s'il manque, un mot de passe temporaire s'affiche au démarrage).
- `PORT` : port du serveur (3000 par défaut).
- `DATA_DIR` : dossier où l'état de la partie est enregistré (`./data` par défaut).
- `TILE_URL` et `TILE_ATTRIBUTION` : fond de carte. Par défaut OpenStreetMap, adapté à quelques dizaines de joueurs. Pour beaucoup de joueurs, utilise un fournisseur de tuiles avec clé (MapTiler, Stadia, etc.).

## Test automatique
`ADMIN_PASSWORD=pw PORT=3100 node server.js` puis, dans un autre terminal, `node test-api.mjs`.
