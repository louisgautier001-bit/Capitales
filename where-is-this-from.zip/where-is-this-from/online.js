'use strict';
// One command to run the game AND get a public https link, without any account:
//   ADMIN_PASSWORD=yourpassword node online.js
const { spawn } = require('child_process');
const PORT = process.env.PORT || '3000';
const env = Object.assign({}, process.env, { PORT });

const server = spawn(process.execPath, [require('path').join(__dirname, 'server.js')], { env, stdio: 'inherit' });
server.on('exit', code => { console.log('Game server stopped.'); process.exit(code || 0); });

setTimeout(() => {
  const tunnel = spawn('npx', ['-y', 'cloudflared', 'tunnel', '--no-autoupdate', '--url', 'http://localhost:' + PORT], { env, shell: true });
  let shown = false;
  const onData = chunk => {
    const m = String(chunk).match(/https:\/\/(?!api\.)[a-z0-9-]+\.trycloudflare\.com/);
    if (m && !shown) {
      shown = true;
      console.log('\n==============================================================');
      console.log(' Share this link with the players:  ' + m[0]);
      console.log(' Host panel (start the game):       ' + m[0] + '/admin');
      console.log(' Keep this window open during the game.');
      console.log('==============================================================\n');
    }
  };
  tunnel.stdout.on('data', onData); tunnel.stderr.on('data', onData);
  tunnel.on('exit', code => { if (!shown) console.log('Could not open the public tunnel (exit ' + code + '). Check your internet connection, or use the Render method in README.md.'); });
  process.on('SIGINT', () => { tunnel.kill(); server.kill(); process.exit(0); });
}, 800);
