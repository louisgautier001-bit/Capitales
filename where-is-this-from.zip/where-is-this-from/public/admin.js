(function () {
'use strict';
var root = document.getElementById('root'), pw = '', s = null, offset = 0, msg = '';
try { pw = sessionStorage.getItem('wif_admin') || ''; } catch (e) {}
var nf = new Intl.NumberFormat('en-US');
function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function call(path, method, body, raw) {
  var h = { 'x-admin': pw };
  if (!raw) h['Content-Type'] = 'application/json';
  return fetch(path, { method: method || 'GET', headers: h, body: raw ? body : (body ? JSON.stringify(body) : undefined) }).then(function (r) {
    return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || 'Error'); return j; });
  });
}
function fmt(ms) { var t = Math.ceil(ms / 1000); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); }
function login() {
  root.innerHTML = '<h1 class="h2">Host panel</h1><form class="join" id="f"><label for="pw">Admin password</label><div class="join-row"><input id="pw" type="password" autocomplete="current-password" required><button class="btn primary" type="submit">Open</button></div><p class="err" id="e">' + esc(msg) + '</p></form>';
  document.getElementById('f').addEventListener('submit', function (e) {
    e.preventDefault(); pw = document.getElementById('pw').value;
    refresh().then(function () { try { sessionStorage.setItem('wif_admin', pw); } catch (x) {} }).catch(function (x) { msg = x.message; login(); });
  });
}
function refresh() { return call('/api/admin/state').then(function (j) { s = j; offset = j.now - Date.now(); msg = ''; draw(); }); }
function draw() {
  var running = s.phase === 'running';
  var phaseLabel = s.phase === 'lobby' ? 'Lobby: players are joining' : running ? 'Game running' : 'Game over: podium is showing';
  root.innerHTML = '<p class="eyebrow">Host panel</p><h1 class="h2">Where is this from?</h1>' +
    '<section class="panel"><h2>Game</h2><p class="sub" style="margin:0 0 8px">' + phaseLabel + ' · <b>' + s.count + '</b> player' + (s.count === 1 ? '' : 's') + '</p>' +
    (running ? '<div class="big-timer" id="bt">' + fmt(Math.max(0, s.endsAt - (Date.now() + offset))) + '</div>' : '') +
    '<div class="row" style="margin-top:12px">' +
    (s.phase === 'lobby' ? '<label>Duration (minutes) <input id="min" type="number" min="1" max="180" value="' + Math.round(s.durationMs / 60000) + '" style="width:90px"></label><button class="btn primary big" id="start">Start the game</button>' : '') +
    (running ? '<button class="btn danger" id="finish">End now and show podium</button>' : '') +
    '<button class="btn danger" id="reset">Reset (remove all players)</button></div><p class="err" id="e">' + esc(msg) + '</p></section>' +
    '<section class="panel"><h2>Standings</h2><ol class="lb">' + s.lb.slice(0, 10).map(function (p, i) { return '<li style="--w:' + (p.total / 1000).toFixed(1) + '%"><span class="rk">' + (i + 1) + '</span><span class="nm">' + esc(p.name) + '<small>' + p.done + '/' + s.rounds + '</small></span><span class="sc">' + nf.format(p.total) + '</span></li>'; }).join('') + '</ol></section>';
  var on = function (id, fn) { var el = document.getElementById(id); if (el) el.addEventListener('click', fn); };
  on('start', function () { act('/api/admin/start', { minutes: +document.getElementById('min').value || 20 }); });
  on('finish', function () { act('/api/admin/finish'); });
  on('reset', function (e) {
    var b = e.currentTarget; if (!b.dataset.armed) { b.dataset.armed = 1; b.textContent = 'Click again to confirm'; setTimeout(function () { b.dataset.armed = ''; b.textContent = 'Reset (remove all players)'; }, 4000); return; }
    act('/api/admin/reset');
  });
}
function act(path, body) { call(path, 'POST', body || {}).then(refresh).catch(function (e) { msg = e.message; draw(); }); }
setInterval(function () { var t = document.getElementById('bt'); if (t && s) t.textContent = fmt(Math.max(0, s.endsAt - (Date.now() + offset))); }, 500);
setInterval(function () { var f = document.activeElement; if (s && !document.hidden && !(f && f.tagName === 'INPUT')) call('/api/admin/state').then(function (j) { s = j; offset = j.now - Date.now(); draw(); }).catch(function () {}); }, 4000);
if (pw) refresh().catch(function () { login(); }); else login();
})();
