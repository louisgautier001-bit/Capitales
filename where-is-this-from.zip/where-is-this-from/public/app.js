(function () {
'use strict';
var $ = function (s, r) { return (r || document).querySelector(s); };
var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
var nf = new Intl.NumberFormat('en-US');
var view = $('#view'), meta = $('#meta'), conn = $('#conn');
var st = null, offset = 0, token = null, me = null, loading = false, curKey = '', map = null, N = 20, MAXPTS = 5000;
var reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
try { token = localStorage.getItem('wif_token'); } catch (e) {}

function api(path, opts) {
  opts = opts || {};
  var h = { 'Content-Type': 'application/json' };
  if (token) h['x-token'] = token;
  return fetch(path, { method: opts.method || 'GET', headers: h, body: opts.body ? JSON.stringify(opts.body) : undefined }).then(function (r) {
    return r.json().then(function (j) { if (!r.ok) { var e = new Error(j.error || 'Something went wrong.'); e.status = r.status; throw e; } return j; });
  });
}
function fmtKm(d) { return d < 1 ? Math.max(1, Math.round(d * 1000)) + ' m' : d < 10 ? d.toFixed(1) + ' km' : nf.format(Math.round(d)) + ' km'; }
function verdict(d) { return d <= 25 ? 'Right on the spot.' : d < 300 ? 'Very close.' : d < 1500 ? 'Not bad.' : d < 4000 ? 'Keep trying.' : 'Other side of the world!'; }
function remaining() { return st ? Math.max(0, st.endsAt - (Date.now() + offset)) : 0; }
function fmtTime(ms) { var s = Math.ceil(ms / 1000); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }
function myIndex() { return me && st ? st.lb.findIndex(function (p) { return p.id === me.id; }) : -1; }
function lbHtml(list, limit) {
  return '<ol class="lb">' + list.slice(0, limit).map(function (p, i) {
    return '<li class="' + (me && p.id === me.id ? 'me' : '') + '" style="--w:' + (p.total / (MAXPTS * N) * 100).toFixed(1) + '%"><span class="rk">' + (i + 1) + '</span><span class="nm">' + esc(p.name) + (p.done < N ? '<small>' + p.done + '/' + N + '</small>' : '') + '</span><span class="sc">' + nf.format(p.total) + '</span></li>';
  }).join('') + '</ol>';
}

/* ---------- header ---------- */
function renderMeta() {
  var h = '';
  if (curKey === 'play' && me) h += '<span>Round <b>' + Math.min(me.done + 1, N) + '</b>/' + N + '</span><span><b>' + nf.format(me.total) + '</b> pts</span>';
  if (st && st.phase === 'running') h += '<span class="timer" id="timer">' + fmtTime(remaining()) + '</span>';
  meta.innerHTML = h;
}
setInterval(function () {
  var t = $('#timer'); if (!t || !st) return;
  var r = remaining(); t.textContent = fmtTime(r); t.classList.toggle('low', r < 120000);
}, 250);

/* ---------- routing ---------- */
var views = {};
function teardown() { stopPoll(); if (map) { map.remove(); map = null; } view.classList.remove('is-play'); }
function route() {
  if (!st || loading) return;
  var key = st.phase === 'ended' ? 'podium' : !me ? 'join' : st.phase === 'lobby' ? 'lobby' : me.done >= N ? 'wait' : 'play';
  if (key !== curKey) { teardown(); curKey = key; view.scrollTop = 0; views[key].enter(); }
  else if (views[key].update) views[key].update();
  renderMeta();
}

/* ---------- join ---------- */
views.join = { enter: function () {
  var running = st.phase === 'running';
  view.innerHTML = '<div class="page"><p class="eyebrow">Icebreaker game</p><h1 class="h1">Where is this from?</h1><div class="stripe" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></div>' +
    '<p class="lead">You get the name of a city, you find it on the map. Drop a pin: the closer you are, the more points you score. After each city you see where everyone else placed theirs. Everyone plays on the same ' + Math.round(st.durationMs / 60000) + '-minute clock.</p>' +
    '<form class="join" id="joinForm" autocomplete="off"><label for="nick">Your nickname</label><div class="join-row"><input id="nick" maxlength="20" placeholder="e.g. Sam" required><button class="btn primary big" type="submit">Join the game</button></div><p class="err" id="joinErr"></p></form>' +
    (running ? '<p class="sub">The game has already started and the clock is ticking. Jump in!</p>' : '') +
    '<dl class="facts"><div><dt>20</dt><dd>cities</dd></div><div><dt>5</dt><dd>continents</dd></div><div><dt>5,000</dt><dd>max points per place</dd></div></dl></div>';
  $('#joinForm').addEventListener('submit', function (e) {
    e.preventDefault();
    api('/api/join', { method: 'POST', body: { name: $('#nick').value } }).then(function (r) {
      token = r.token; try { localStorage.setItem('wif_token', token); } catch (x) {}
      return loadMe();
    }).catch(function (x) { $('#joinErr').textContent = x.message; });
  });
} };
function loadMe() { return api('/api/me').then(function (m) { me = m; loading = false; route(); }).catch(function (e) { loading = false; if (e.status === 401) { token = null; me = null; try { localStorage.removeItem('wif_token'); } catch (x) {} } route(); }); }

/* ---------- lobby ---------- */
views.lobby = { enter: function () {
  view.innerHTML = '<div class="page"><p class="eyebrow">You are in, ' + esc(me.name) + '</p><h1 class="h1">Waiting for the host to start</h1><div class="stripe" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></div>' +
    '<p class="lead">The game starts for everyone at the same moment. You will have ' + Math.round(st.durationMs / 60000) + ' minutes to place as many pins as you can.</p><p class="sub" id="lobbyCount"></p><ul class="chips" id="lobbyNames"></ul></div>';
  views.lobby.update();
}, update: function () {
  $('#lobbyCount').textContent = st.count + ' player' + (st.count === 1 ? '' : 's') + ' in the lobby';
  $('#lobbyNames').innerHTML = (st.names || []).map(function (n) { return '<li class="' + (n === me.name ? 'me' : '') + '">' + esc(n) + '</li>'; }).join('');
} };

/* ---------- play ---------- */
var guess = null, gm = null, layers = [], round = null, nextRound = null, busy = false;
function pinIcon(html, size, anchor) { return L.divIcon({ className: 'pin', iconSize: size, iconAnchor: anchor, html: html }); }
var guessIcon = function () { return pinIcon('<svg width="28" height="38" viewBox="-14 -36 28 38"><path class="gp" d="M0 0L-8.66 -15A10 10 0 1 1 8.66 -15Z"/><circle class="gd" cx="0" cy="-20" r="3.6"/></svg>', [28, 38], [14, 36]); };
var targetIcon = function () { return pinIcon('<svg width="40" height="40" viewBox="-20 -20 40 40"><circle class="tp-halo" r="14"/><circle class="tp-ring" r="14"/><circle class="tp-dot" r="5"/></svg>', [40, 40], [20, 20]); };
views.play = { enter: function () {
  view.classList.add('is-play');
  view.innerHTML = '<section class="play"><div class="shot" id="shot"></div><div class="mapwrap" id="mapwrap"><div id="map"></div><div class="hud" id="hud"></div>' +
    '<div class="act" id="act"><button class="btn primary big" id="validate" disabled>Lock in my guess</button></div></div><div class="result" id="result" hidden></div></section>';
  map = L.map('map', { minZoom: 1, maxZoom: 18, worldCopyJump: true, zoomSnap: 0.5, wheelPxPerZoomLevel: 90, maxBounds: [[-85, -540], [85, 540]], maxBoundsViscosity: 0.7 });
  L.tileLayer(st.tileUrl, { attribution: st.tileAttr, maxZoom: 18 }).addTo(map);
  map.setView([25, 10], window.innerWidth < 700 ? 1.5 : 2);
  map.on('click', function (e) { if (!busy && !$('#validate').hidden && !round.answered) place(e.latlng); });
  $('#validate').addEventListener('click', submit);
  $('#result').addEventListener('click', function (e) { if (e.target.closest('[data-next]')) nextStep(); });
  startRound();
} };
function place(ll) {
  guess = ll.wrap();
  if (!gm) { gm = L.marker(guess, { icon: guessIcon(), draggable: true }).addTo(map); gm.on('dragend', function () { guess = gm.getLatLng().wrap(); }); }
  else gm.setLatLng(guess);
  $('#validate').disabled = false; $('#hud').textContent = 'Pin placed. Drag it to adjust.';
}
function showShot(r) {
  $('#shot').innerHTML = '<span class="chip">Mystery place ' + (r.i + 1) + ' of ' + N + '</span><div class="clue"><small>Where is\u2026</small><h2 class="city">' + esc(r.city) + '</h2><p>' + esc(r.country) + '</p></div>';
}
function startRound() {
  var go = function (r) {
    stopPoll(); round = r; round.answered = false; guess = null; busy = false; clearOthers();
    if (gm) { map.removeLayer(gm); gm = null; }
    layers.forEach(function (l) { map.removeLayer(l); }); layers = [];
    showShot(r);
    $('#result').hidden = true; $('#act').hidden = false; $('#validate').hidden = false; $('#validate').disabled = true;
    $('#hud').textContent = 'Click the map to place your pin';
    map.invalidateSize(); map.setView([25, 10], window.innerWidth < 700 ? 1.5 : 2, { animate: !reduceMotion });
    renderMeta();
  };
  if (nextRound) { var r = nextRound; nextRound = null; go(r); return; }
  api('/api/round').then(go).catch(function (e) { $('#hud').textContent = e.message; if (e.status === 409) refreshState(); });
}
var otherLayers = {}, fitAll = true, pollT = null, lastTarget = null, lastResult = null;
var PAL = ['#E4745B', '#E0A92E', '#4FA06A', '#3B9BB8', '#9A62B0', '#D45C86'];
function hashColor(id) { var h = 0; for (var k = 0; k < id.length; k++) h = (h * 31 + id.charCodeAt(k)) >>> 0; return PAL[h % PAL.length]; }
function clearOthers() { Object.keys(otherLayers).forEach(function (k) { if (map) map.removeLayer(otherLayers[k]); }); otherLayers = {}; lastResult = null; }
function stopPoll() { if (pollT) { clearInterval(pollT); pollT = null; } }
function startPoll(i) {
  stopPoll();
  pollT = setInterval(function () {
    if (curKey !== 'play' || !round || round.i !== i || !round.answered) return stopPoll();
    api('/api/results?i=' + i).then(function (r) { drawOthers(r.others); }).catch(function () {});
  }, 4000);
}
function drawOthers(list) {
  if (!map || !lastResult) return;
  var seen = {};
  list.forEach(function (o) {
    seen[o.id] = 1;
    var tip = o.name + ' · ' + fmtKm(o.d) + ' · ' + nf.format(o.p) + ' pts';
    if (otherLayers[o.id]) { otherLayers[o.id].setLatLng([o.lat, o.lng]).setTooltipContent(tip); return; }
    var c = hashColor(o.id);
    otherLayers[o.id] = L.circleMarker([o.lat, o.lng], { radius: 7, color: '#fff', weight: 2, fillColor: c, fillOpacity: 0.95 }).bindTooltip(tip, { direction: 'top', offset: [0, -6] }).addTo(map);
  });
  Object.keys(otherLayers).forEach(function (k) { if (!seen[k]) { map.removeLayer(otherLayers[k]); delete otherLayers[k]; } });
  var rows = list.map(function (o) { return { name: o.name, d: o.d, p: o.p, me: false }; });
  rows.push({ name: me.name + ' (you)', d: lastResult.d, p: lastResult.p, me: true });
  rows.sort(function (x, y) { return y.p - x.p; });
  var top = rows.slice(0, 5), mi = rows.findIndex(function (x) { return x.me; });
  if (mi >= 5) top.push(rows[mi]);
  var html = top.map(function (x) {
    var rank = rows.indexOf(x) + 1;
    return '<li class="' + (x.me ? 'me' : '') + '" style="--w:' + (x.p / MAXPTS * 100).toFixed(1) + '%"><span class="rk">' + rank + '</span><span class="nm">' + esc(x.name) + '<small>' + fmtKm(x.d) + '</small></span><span class="sc">+' + nf.format(x.p) + '</span></li>';
  }).join('');
  var el = $('#roundLb'); if (el) el.innerHTML = html;
  var c = $('#roundCount'); if (c) c.textContent = rows.length + ' player' + (rows.length === 1 ? '' : 's') + ' answered this place so far. Hover or tap a dot to see who it is.';
}
function fitView() {
  if (!map || !lastTarget) return;
  var pts = [guess, lastTarget];
  if (fitAll) Object.keys(otherLayers).forEach(function (k) { pts.push(otherLayers[k].getLatLng()); });
  var res = $('#result'), mr = $('#mapwrap').getBoundingClientRect(), rr = res.getBoundingClientRect(), over = 0;
  if (rr.left < mr.right && rr.right > mr.left && rr.top < mr.bottom && rr.bottom > mr.top) over = mr.bottom - rr.top;
  map.invalidateSize();
  map.fitBounds(L.latLngBounds(pts), { paddingTopLeft: [50, 70], paddingBottomRight: [50, 40 + over], maxZoom: 7, animate: !reduceMotion });
}
function submit() {
  if (!guess || busy) return; busy = true; $('#validate').disabled = true;
  api('/api/guess', { method: 'POST', body: { i: round.i, lat: guess.lat, lng: guess.lng } }).then(function (a) {
    round.answered = true; me.done = a.done; me.total = a.total; lastResult = a; fitAll = true;
    if (gm) gm.dragging.disable();
    var target = L.latLng(a.target.lat, a.target.lng); lastTarget = target;
    layers.push(L.marker(target, { icon: targetIcon(), interactive: false, zIndexOffset: 500 }).addTo(map));
    layers.push(L.polyline([guess, target], { color: '#12202C', weight: 3, dashArray: '7 7', opacity: 0.85 }).addTo(map));
    var last = a.done >= N, res = $('#result');
    res.innerHTML = '<div class="res-top"><div><div class="res-k">Your pin is</div><div class="res-d">' + fmtKm(a.d) + ' away</div></div><div class="res-p" id="resP">+0 pts</div></div>' +
      '<div class="pbar"><i style="width:' + (a.p / MAXPTS * 100).toFixed(1) + '%"></i></div><p class="res-v">' + verdict(a.d) + '</p>' +
      '<h3 class="res-t">' + esc(a.city) + '<span>' + esc(a.country) + '</span></h3><p class="res-n">' + esc(a.note) + '</p>' +
      '<div class="rr"><div class="rr-h"><h4>Everyone on this place</h4><button class="btn sm" id="fitBtn" type="button">Focus on my result</button></div><p class="res-v" id="roundCount"></p><ol class="lb" id="roundLb"></ol></div>' +
      '<div class="res-bot"><span class="legend"><span><i></i>Your pin</span><span><i class="t"></i>The place</span></span><button class="btn primary" data-next>' + (last ? 'See my score' : 'Next place') + '</button></div>';
    res.hidden = false; $('#act').hidden = true; $('#hud').textContent = 'Here is the real location';
    $('#fitBtn').addEventListener('click', function () { fitAll = !fitAll; this.textContent = fitAll ? 'Focus on my result' : 'Show everyone'; fitView(); });
    countUp($('#resP'), a.p); renderMeta();
    drawOthers(a.others);
    if (!last) api('/api/round').then(function (r) { nextRound = r; }).catch(function () {});
    setTimeout(fitView, 60);
    startPoll(round.i);
  }).catch(function (e) { busy = false; $('#validate').disabled = false; $('#hud').textContent = e.message; if (e.status === 409) refreshState(); });
}
function nextStep() { if (me.done >= N) { route(); } else startRound(); }
function countUp(el, to) {
  if (reduceMotion || !to) { el.textContent = '+' + nf.format(to) + ' pts'; return; }
  var t0 = performance.now();
  (function f(now) { var u = Math.min(1, (now - t0) / 700); el.textContent = '+' + nf.format(Math.round(to * (1 - Math.pow(1 - u, 3)))) + ' pts'; if (u < 1) requestAnimationFrame(f); })(t0);
}

/* ---------- waiting for the clock ---------- */
views.wait = { enter: function () {
  view.innerHTML = '<div class="page"><p class="eyebrow">All 20 places done</p><h1 class="big-n">' + nf.format(me.total) + '<small>/ ' + nf.format(MAXPTS * N) + ' pts</small></h1>' +
    '<p class="sub" id="waitRank" style="margin-top:12px"></p><p class="lead">The podium appears for everyone when the clock hits 00:00. Standings update live.</p><div id="waitLb"></div></div>';
  views.wait.update();
}, update: function () {
  var i = myIndex(); $('#waitRank').textContent = i >= 0 ? 'You are currently #' + (i + 1) + ' of ' + st.count + '.' : '';
  $('#waitLb').innerHTML = lbHtml(st.lb, 10);
} };

/* ---------- podium ---------- */
views.podium = { enter: function () {
  view.innerHTML = '<div class="page"><p class="eyebrow">Time is up</p><h1 class="h2">Final podium</h1><div class="podium" id="pod"></div><div id="mine"></div><div id="finalLb"></div></div>';
  views.podium.update();
}, update: function () {
  var top = st.lb.slice(0, 3), order = [1, 0, 2];
  $('#pod').innerHTML = order.map(function (k) {
    var p = top[k]; if (!p) return '<div class="slot empty"></div>';
    return '<div class="slot p' + (k + 1) + '"><div class="who"><b>' + esc(p.name) + '</b><span>' + nf.format(p.total) + ' pts</span></div><div class="bar">' + (k + 1) + '</div></div>';
  }).join('');
  var i = myIndex(), mine = $('#mine');
  if (me && i >= 0) mine.innerHTML = '<p class="mine">You finished #' + (i + 1) + ' of ' + st.count + ' with ' + nf.format(st.lb[i].total) + ' points.</p>';
  else if (me) api('/api/me').then(function (m) { me = m; mine.innerHTML = '<p class="mine">You finished #' + m.rank + ' of ' + m.count + ' with ' + nf.format(m.total) + ' points.</p>'; }).catch(function () {});
  $('#finalLb').innerHTML = lbHtml(st.lb, 50);
} };

/* ---------- live state ---------- */
function setState(s) { st = s; offset = s.now - Date.now(); N = s.rounds || N; route(); }
function refreshState() { route(); }
function boot() {
  var es = new EventSource('/api/events');
  es.addEventListener('state', function (e) { conn.hidden = true; setState(JSON.parse(e.data)); });
  es.onerror = function () { conn.hidden = false; };
  if (token) { loading = true; loadMe(); }
}
boot();
})();
