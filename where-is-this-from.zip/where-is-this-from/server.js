'use strict';
// Where is this from? — icebreaker game server. No dependencies, Node 18+.
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');

const PORT = +process.env.PORT || 3000;
const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUB = path.join(__dirname, 'public');
const TILE_URL = process.env.TILE_URL || 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const TILE_ATTR = process.env.TILE_ATTRIBUTION || '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
let ADMIN = process.env.ADMIN_PASSWORD || '';
if (!ADMIN) { ADMIN = crypto.randomBytes(4).toString('hex'); console.log('No ADMIN_PASSWORD set. Temporary admin password: ' + ADMIN); }
const ROUNDS = JSON.parse(fs.readFileSync(path.join(__dirname, 'rounds.json'), 'utf8'));
const N = ROUNDS.length, MAXPTS = 5000;
fs.mkdirSync(DATA, { recursive: true });
const STATE_FILE = path.join(DATA, 'state.json');

let S = { phase: 'lobby', startedAt: 0, endsAt: 0, durationMs: 20 * 60000, players: {} };
try { S = Object.assign(S, JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'))); } catch (e) {}
let saveT = null;
function save() {
  clearTimeout(saveT);
  saveT = setTimeout(() => fs.writeFile(STATE_FILE + '.tmp', JSON.stringify(S), err => { if (!err) fs.rename(STATE_FILE + '.tmp', STATE_FILE, () => {}); }), 400);
}

/* ---------- game logic ---------- */
function dist(a, b) {
  const r = Math.PI / 180, dl = (b.lat - a.lat) * r, dn = (b.lng - a.lng) * r;
  const s = Math.sin(dl / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dn / 2) ** 2;
  return 2 * 6371.0088 * Math.asin(Math.min(1, Math.sqrt(s)));
}
const points = d => d <= 25 ? MAXPTS : Math.round(MAXPTS * Math.exp(-d / 1492.7));
function board() {
  return Object.values(S.players)
    .map(p => ({ id: p.id, name: p.name, total: p.total, done: p.answers.length, at: p.lastAt || p.joinedAt }))
    .sort((a, b) => b.total - a.total || a.at - b.at);
}
function publicState() {
  const b = board();
  return { phase: S.phase, endsAt: S.endsAt, durationMs: S.durationMs, now: Date.now(), count: b.length, rounds: N,
    lb: b.slice(0, 50), names: S.phase === 'lobby' ? b.map(x => x.name).slice(0, 200) : undefined,
    tileUrl: TILE_URL, tileAttr: TILE_ATTR };
}
function endGame() { if (S.phase === 'running') { S.phase = 'ended'; S.endsAt = Math.min(S.endsAt, Date.now()); dirty = true; save(); } }
setInterval(() => { if (S.phase === 'running' && Date.now() >= S.endsAt) endGame(); }, 500);

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.json': 'application/json', '.map': 'application/json' };

// Pins of every other player who has already answered round i (only shown to someone who answered it too).
function othersFor(i, me) {
  return Object.values(S.players).filter(q => q !== me && q.answers.length > i).slice(0, 300)
    .map(q => { const a = q.answers[i]; return { id: q.id, name: q.name, lat: a.lat, lng: a.lng, d: a.d, p: a.p }; });
}

/* ---------- live updates (server-sent events) ---------- */
const clients = new Set();
let dirty = false;
function sendState(res) { res.write('event: state\ndata: ' + JSON.stringify(publicState()) + '\n\n'); }
setInterval(() => { if (dirty) { dirty = false; clients.forEach(sendState); } }, 1000);
setInterval(() => clients.forEach(r => r.write(': ping\n\n')), 20000);

/* ---------- http helpers ---------- */
function json(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); }
function body(req, limit) {
  return new Promise((ok, no) => {
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limit) { no(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => ok(Buffer.concat(chunks))); req.on('error', no);
  });
}
async function jbody(req) { try { return JSON.parse((await body(req, 20000)).toString() || '{}'); } catch (e) { return {}; } }
function isAdmin(req) {
  const a = Buffer.from(String(req.headers['x-admin'] || '')), b = Buffer.from(ADMIN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function player(req) { return S.players[String(req.headers['x-token'] || '')] || null; }
const cleanName = s => String(s || '').replace(/[\u0000-\u001f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 20);

/* ---------- api ---------- */
async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  if (p === '/api/config') return json(res, 200, { rounds: N, tileUrl: TILE_URL, tileAttr: TILE_ATTR });
  if (p === '/api/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    sendState(res); clients.add(res); req.on('close', () => clients.delete(res)); return;
  }
  if (p === '/api/join' && m === 'POST') {
    const b = await jbody(req), existing = S.players[String(b.token || '')];
    if (existing) return json(res, 200, { token: b.token, id: existing.id, name: existing.name });
    if (S.phase === 'ended') return json(res, 403, { error: 'The game is over.' });
    const name = cleanName(b.name);
    if (name.length < 2) return json(res, 400, { error: 'Pick a nickname with at least 2 characters.' });
    if (Object.keys(S.players).length >= 500) return json(res, 403, { error: 'The game is full.' });
    if (Object.values(S.players).some(x => x.name.toLowerCase() === name.toLowerCase())) return json(res, 409, { error: 'That nickname is already taken.' });
    const token = crypto.randomBytes(16).toString('hex'), id = crypto.randomBytes(4).toString('hex');
    S.players[token] = { id, name, answers: [], total: 0, joinedAt: Date.now(), lastAt: 0 };
    dirty = true; save(); return json(res, 200, { token, id, name });
  }
  if (p === '/api/me') {
    const me = player(req); if (!me) return json(res, 401, { error: 'Unknown player.' });
    const b = board(), rank = b.findIndex(x => x.id === me.id) + 1;
    return json(res, 200, { id: me.id, name: me.name, total: me.total, done: me.answers.length, rank, count: b.length, answers: me.answers.map(a => ({ d: a.d, p: a.p })) });
  }
  if (p === '/api/round') {
    const me = player(req); if (!me) return json(res, 401, { error: 'Unknown player.' });
    if (S.phase !== 'running') return json(res, 409, { error: 'The game is not running.' });
    const i = me.answers.length; if (i >= N) return json(res, 409, { error: 'You have finished all rounds.' });
    const r = ROUNDS[i];
    return json(res, 200, { i, n: N, city: r.city, country: r.country });
  }
  if (p === '/api/results') {
    const me = player(req); if (!me) return json(res, 401, { error: 'Unknown player.' });
    const i = +url.searchParams.get('i');
    if (!Number.isInteger(i) || i < 0 || i >= N || me.answers.length <= i) return json(res, 409, { error: 'Answer this round first.' });
    return json(res, 200, { i, others: othersFor(i, me) });
  }
  if (p === '/api/guess' && m === 'POST') {
    const me = player(req); if (!me) return json(res, 401, { error: 'Unknown player.' });
    if (S.phase !== 'running' || Date.now() > S.endsAt + 1500) return json(res, 409, { error: 'Time is up.' });
    const b = await jbody(req), i = me.answers.length;
    if (i >= N || b.i !== i) return json(res, 409, { error: 'Wrong round.' });
    const lat = +b.lat, lng = +b.lng;
    if (!isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return json(res, 400, { error: 'Invalid position.' });
    const r = ROUNDS[i], d = dist({ lat, lng }, r), pts = points(d);
    me.answers.push({ lat, lng, d, p: pts }); me.total += pts; me.lastAt = Date.now();
    dirty = true; save();
    return json(res, 200, { d, p: pts, total: me.total, done: me.answers.length, target: { lat: r.lat, lng: r.lng }, city: r.city, country: r.country, note: r.note, others: othersFor(i, me) });
  }
  if (p.startsWith('/api/admin/')) {
    if (!isAdmin(req)) return json(res, 401, { error: 'Wrong admin password.' });
    if (p === '/api/admin/state') return json(res, 200, publicState());
    if (p === '/api/admin/start' && m === 'POST') {
      if (S.phase !== 'lobby') return json(res, 409, { error: 'Reset the game first.' });
      const b = await jbody(req), min = Math.min(180, Math.max(1, +b.minutes || 20));
      S.phase = 'running'; S.startedAt = Date.now(); S.durationMs = min * 60000; S.endsAt = S.startedAt + S.durationMs;
      dirty = true; save(); return json(res, 200, publicState());
    }
    if (p === '/api/admin/finish' && m === 'POST') { endGame(); return json(res, 200, publicState()); }
    if (p === '/api/admin/reset' && m === 'POST') { S = { phase: 'lobby', startedAt: 0, endsAt: 0, durationMs: S.durationMs, players: {} }; dirty = true; save(); return json(res, 200, publicState()); }
  }
  json(res, 404, { error: 'Not found.' });
}

/* ---------- server ---------- */
http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    let rel = url.pathname === '/' ? '/index.html' : url.pathname === '/admin' ? '/admin.html' : decodeURIComponent(url.pathname);
    const f = path.normalize(path.join(PUB, rel));
    if (!f.startsWith(PUB + path.sep)) { res.writeHead(404); return res.end(); }
    fs.stat(f, (err, st) => {
      if (err || !st.isFile()) { res.writeHead(404); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      fs.createReadStream(f).pipe(res);
    });
  } catch (e) { if (!res.headersSent) json(res, 500, { error: 'Server error.' }); }
}).listen(PORT, () => console.log('Game running on http://localhost:' + PORT + '  (admin: /admin)'));
