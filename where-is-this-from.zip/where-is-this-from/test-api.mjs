// Quick end-to-end API test: node test-api.mjs (server must run on :3100 with ADMIN_PASSWORD=pw)
const B='http://localhost:3100'; let fails=0;
const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m); if(!c){fails++;}};
const j=async(p,o={})=>{const r=await fetch(B+p,o);return {s:r.status,b:await r.json().catch(()=>({}))};};
const post=(p,body,h={})=>j(p,{method:'POST',headers:{'Content-Type':'application/json',...h},body:JSON.stringify(body||{})});
let r=await post('/api/join',{name:'Ana'}); ok(r.s===200&&r.b.token,'join in lobby'); const A=r.b.token;
r=await post('/api/join',{name:'ana'}); ok(r.s===409,'duplicate nickname rejected');
r=await post('/api/join',{name:'Bo'}); const Bt=r.b.token;
r=await post('/api/join',{name:'Cy'}); const Ct=r.b.token;
r=await j('/api/round',{headers:{'x-token':A}}); ok(r.s===409,'no rounds before start');
r=await post('/api/admin/start',{minutes:1}); ok(r.s===401,'admin needs password');
r=await post('/api/admin/start',{minutes:1},{'x-admin':'pw'}); ok(r.s===200&&r.b.phase==='running','admin starts game');
r=await j('/api/round',{headers:{'x-token':A}}); ok(r.s===200&&r.b.i===0&&!('lat' in r.b)&&r.b.city==='Paris','round 0 is Paris, served without coordinates');
r=await j('/api/results?i=0',{headers:{'x-token':A}}); ok(r.s===409,'results hidden until you answered');
r=await post('/api/guess',{i:1,lat:0,lng:0},{'x-token':A}); ok(r.s===409,'cannot skip rounds');
r=await post('/api/guess',{i:0,lat:48.8566,lng:2.3522},{'x-token':A}); ok(r.s===200&&r.b.p===5000&&r.b.d<1&&r.b.others.length===0,'perfect guess = 5000, nobody else yet');
r=await post('/api/guess',{i:0,lat:0,lng:0},{'x-token':A}); ok(r.s===409,'cannot answer same round twice');
r=await post('/api/guess',{i:0,lat:0,lng:0},{'x-token':Bt}); ok(r.s===200&&r.b.p<300&&r.b.others.length===1&&r.b.others[0].name==='Ana'&&r.b.others[0].lat===48.8566,'far guess = few points ('+r.b.p+') and Bo sees Ana pin');
r=await post('/api/guess',{i:0,lat:30,lng:5},{'x-token':Ct}); ok(r.s===200&&r.b.p>0&&r.b.p<5000&&r.b.others.length===2,'mid guess ('+r.b.p+') sees both others');
const meA=(await j('/api/me',{headers:{'x-token':A}})).b; r=await j('/api/results?i=0',{headers:{'x-token':A}}); ok(r.s===200&&r.b.others.length===2&&!r.b.others.some(o=>o.id===meA.id),'results list the 2 others for round 0, not me');
for(let i=1;i<20;i++){ const x=await post('/api/guess',{i,lat:0,lng:0},{'x-token':A}); if(x.s!==200){ok(false,'round '+i);break;} }
r=await j('/api/me',{headers:{'x-token':A}}); ok(r.b.done===20&&r.b.rank===1,'Ana finished 20 rounds, rank 1 (total '+r.b.total+')');
r=await post('/api/guess',{i:20,lat:0,lng:0},{'x-token':A}); ok(r.s===409,'no 21st round');
// SSE
const ctrl=new AbortController(); const sse=await fetch(B+'/api/events',{signal:ctrl.signal}); const rd=sse.body.getReader(); const {value}=await rd.read();
const txt=new TextDecoder().decode(value); ok(txt.includes('event: state')&&txt.includes('"phase":"running"'),'SSE sends running state'); ctrl.abort();
r=await post('/api/admin/finish',{},{'x-admin':'pw'}); ok(r.b.phase==='ended','admin ends game');
r=await post('/api/guess',{i:1,lat:0,lng:0},{'x-token':Bt}); ok(r.s===409,'guess refused after end');
r=await post('/api/join',{name:'Late'}); ok(r.s===403,'no joining after end');
r=await j('/api/admin/state',{headers:{'x-admin':'pw'}}); ok(r.b.lb[0].name==='Ana'&&r.b.lb.length===3&&r.b.lb.length===3,'podium order + admin state');
r=await post('/api/admin/reset',{},{'x-admin':'pw'}); ok(r.b.phase==='lobby'&&r.b.count===0,'reset');
const t=await fetch(B+'/../server.js'); const t2=await fetch(B+'/%2e%2e/server.js'); ok(t2.status===404,'path traversal blocked');
const p2=await fetch(B+'/'); ok((await p2.text()).includes('Where is this from?'),'index served');
console.log(fails?('FAILED '+fails):'ALL PASSED'); process.exit(fails?1:0);
